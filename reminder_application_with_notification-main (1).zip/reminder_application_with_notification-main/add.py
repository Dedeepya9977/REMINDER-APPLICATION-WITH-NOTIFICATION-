def addThese(x,y)
    return x + y
print(addThese(7,8))

