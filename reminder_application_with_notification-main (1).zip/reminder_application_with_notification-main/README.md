**Reminder_Application_with_Notification_Team87**

PROJECT :

A simple python program based notification reminder which remindes the user to drink water after certain interval of time. 

DESCRIPTION:

This program will track time and show you notification after a brief period of time to remind you to drink water. We are going to use time, win10Toast, date time  modules to show the notification and the time module to run the module after a fixed period of time.
The program coded first asks its user to input time interval for notification. Then until user ends script, it sends repeated notifications to user to drink water. After each interval it creates a text file which contains a log of when user drank water.

OBJECTIVE:

Gives a reminder to drink water for a person to be healthy
This app remindes a person to drink the minimum amoount of fluid intsake that has to be taken in a day
The U.S. National Academies of Sciences, Engineering, and Medicine determined that an adequate daily fluid intake forr a day is:
 3.7 liter of fluids a day for men 
2.7 liters of fluids a day for women

Team Members:

**.** Nabieha - 21wh5a0202 - EEE 

**.** K.Dedeepya - 20wh1a0436 - ECE-A 

**.** Srujana - 20wh1a12b2 - IT 

**.** P.Akshitha - 20wh1a1260 - IT 

**.** Snehitha - 20wh1a0240 - EEE 

**.** Sweety - 20wh1a0580 - CSE 
